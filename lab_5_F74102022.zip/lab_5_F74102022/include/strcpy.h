#ifndef STRCPY_H
#define STRCPY_H

char *sstrcpy(char *dest, const char *src);

#endif /* STRCPY_H */
